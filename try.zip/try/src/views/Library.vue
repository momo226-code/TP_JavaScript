<template>
  <div id="filtre">
    <!-- Section du filtre -->
    <div class="filter-section">
      <FilterBook @filter-book="filterbook" />
    </div>

    <!-- Section des emplois -->
    <div class="jobs-section">
      <h1>Liste des documuments </h1>
      <!-- Affichage des emplois avec un bouton pour voir les détails -->
      <div v-for="item in filteredbook" :key="item.id" class="job-item">
        <h2>{{ item.titre }}</h2> <!-- Titre de l'emploi -->
        <h2>{{ item.categorie }}</h2>
        <router-link :to="'/book/' + item.id">
          <button>Voir détails</button>
        </router-link>
      </div>
    </div>
  </div>
</template>
  
  <script>
  import FilterBook from "@/components/FilterBook.vue";


  export default {


  name: 'Library', // Nom du composant
  components: {
    FilterBook 
  },
    data() {
      // Retourne un objet contenant les données du composant
      return {
        filteredbook: [], // The filtered list of jobs

      };
    },
  
    mounted() {

       // Fonction pour récupérer les emplois depuis le serveur
       fetch('http://localhost:3000/livres')
          .then((response) => response.json())  // Convertir la réponse en JSON
          .then((data) => {
            this.filteredbook=data; // Assigner les emplois récupérés à 'jobs'
          })
          .catch((error) => console.log(error)) ; 
      
    },
  
    methods: {


      filterbook(filterCriteria) {
      this.filteredbook = this.filteredbook.filter((book) => {
        return (
          (filterCriteria.titre ? book.titre.includes(filterCriteria.titre) : true) &&
          (filterCriteria.auteur
            ? book.auteur == filterCriteria.auteur
            : true)
        );
      });
    }
    },
  };
  </script>
  


  <style scoped>
/* Conteneur principal pour séparer la section de filtre et la section des emplois */
#filtre {
  display: flex;    
  margin-top: 20px;
  margin-left: 10%;
  min-width: 50px;
}

/* Section pour le formulaire de filtre */
.filter-section {
   
 margin-right: 20px;
  flex: 1;
  max-width: 400px; /* Limiter la largeur du formulaire de filtre */
}

/* Section pour afficher la liste des emplois */
.jobs-section {
  flex: 2;
  display: grid;
  gap: 50px; /* Espacement entre chaque élément */
  
}

/* Style pour chaque emploi */
.job-item {
  background-color: #e5d6d6; /* Fond léger */
  border: 1px solid #ddd; /* Bordure pour séparer les emplois */
  border-radius: 8px; /* Coins arrondis */
  padding: 10px; /* Espacement intérieur */
  text-align: center;
  width: 25%;
  
 
}

.job-item:hover {
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2); /* Ombre plus prononcée */
}

/* Style pour le titre de l'emploi */
.job-item h2 {
  font-size: 30px;
  font-weight: bold;
  color: #333;
  margin-bottom: 10px;
}

/* Style pour la description de l'emploi */
.job-item p {
  font-size: 14px;
  color: #666;
  margin-bottom: 10px;
}

/* Style pour le salaire et l'expérience */
.job-item p strong {
  font-weight: bold;
  color: #333;
}

/* Style pour le bouton "Voir détails" */
.job-item button {
  padding: 20px;
  background-color: #4CAF50;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 25px ;
}

.job-item button:hover {
  background-color: #45a049; /* Couleur du bouton au survol */
}
</style>

  