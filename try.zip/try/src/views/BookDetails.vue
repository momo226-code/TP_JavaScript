
<template>

    <div v-if="book"  id="details">
        <h2>Détails du livre</h2>
        <p><strong>Titre : {{ book.titre }}</strong></p>
        <p><strong>Auteur : {{ book.auteur }}</strong></p>
        <p><strong>Année : {{book.annee }}</strong></p>
        <p><strong>Categorie: {{ book.categorie }}</strong></p>
        <p><strong>Resumé: {{ book.resume }}</strong></p>
        <p><strong>Statut: {{ book.disponible }}</strong></p>
    </div>
   
  </template>
  
  
  <script>
  
  export default{
    data(){
        return {
            book:null
        }
    },
  
  

    mounted(){
        const bookid = this.$route.params.id;  // Récupère l'ID depuis les paramètres de la route
        this.fetchbook(bookid) ; 
    },

    methods:{

        fetchbook(bookid){
            fetch(`http://localhost:3000/livres/${bookid}`)
                .then(response=>response.json())
                .then(data =>
                    {this.book = data
                        console.log(this.book)
                    }
                )
                .catch(error=>{
                    console.error('Erruer de verification de details',error)
                }) 
            

        }
    
} 
  
  }
  
  
  
  </script>
  
  <style>
  
  #details{
    background-color: aqua;
    max-width: 500px;
    min-width: 300px;
    margin-left: 10%;
    margin-right: 10%;
    margin-top: 5%;
    align-items: center;
    font-size: 30px;
    border-radius: 10px;
    padding: 20px;
  }
  
  
  </style>
  