<template>
  <nav>
    <router-link to="/">Home Librairy</router-link>
  </nav>
  <router-view/>
</template>


<script>
export default {
  name:'App'
}
</script>

<style>
nav {
  gap: 20px;
  display: flex;
  padding: 10px;
  background-color: aquamarine;
}
router-link {
  text-decoration: none;
  color: #333;
  padding: 8px 16px;
  border-radius: 4px;
}

router-link:hover {
  background-color: #ddd;
}

#app{
  margin-right: 50px;
  margin-left: 50px;
  align-items: center ;
  font-size: 20px;
}
</style>

