


<template>
    <form >

        <h1>Recherche de livres</h1>
        <div id="formulaire">
        <label for="title">Titre</label>
        <input v-model="filter.titre" type="text" id="title" placeholder="Recherche par titre"  @input="applyFilter"/>
      </div>

      <div id="formulaire">
        <label for="auteur">Auteur</label>
        <input v-model="filter.auteur" type="text" id="auteur" placeholder="Recherche par auteur" @input="applyFilter"/>
      </div>

      <button @click="filtragedisponible" v-model="disponible">Documents disponibles</button>
      <button @click="filtrageemprunté" v-model="emprunté">Documents empruntés</button>

    </form>


</template>iltrageemprunté


<script>
export default {
    data(){
        return{
            filter: {
                titre: "",
                auteur: "",
            },

            disponible :'',
            emprunté :'',
        }
    },

    methods: {
    // Emit the filter criteria to the parent component
    applyFilter() {
      this.$emit("filter-book", this.filter); // Pass the filter criteria to parent
    },

    filtragedisponible(){
      console.log(disponible)
      this.$emit("filter-book", this.filter);
    },

    filtrageemprunté(){
      console.log(emprunté)
      this.$emit("filter-book", this.filter);

    }


  },


}
</script>

<style scoped>

form {
  max-width: 500px;
  margin: 30px auto;
  padding: 30px;
  border: 1px solid #ccc;
  border-radius: 8px;
  background-color: #f9f9f9;
}

label{

    font-size: 35px;
    margin-bottom: 5px;

}

input{

    padding: 15px;
    font-size: 10px;
    border: 1px solid rgb(82, 67, 67);
    border-radius: 4px;
}

#formulaire{
    margin-bottom: 15px;
    display: flex;
    flex-direction: column;
    
}

input::placeholder{
    font-size:15px
}




</style>